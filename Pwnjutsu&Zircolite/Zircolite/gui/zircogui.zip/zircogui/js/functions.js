function clear(obj) {
    var indexColumn = $(obj).parents("th").index();
    $(obj).closest('.table').find(".clean-filter").each(function (index, elem) {
        if (index == indexColumn) {
            $(this).val('');
            $(this).trigger('change');
        }
    });
}

function trash(obj) {
    $(obj).closest('.table').find(".clean-filter").each(function (index, elem) {
        $(this).val('');
        $(this).trigger('change');
    });
}

function formatInit(obj)
{
    $.each($('.select-filter', obj.table().header()), function () {
        var column = obj.column($(this).index());
        var select = $('select', this);
        column.data().unique().sort().each(function (d, j) {
            select.append('<option value="' + d + '">' + d + '</option>');
            select.val('');
        });

        $('select', this).on('change', function () {

            if ($(this).val() !== null) {
                var val = $.fn.dataTable.util.escapeRegex($(this).val());
                column.search(val ? '^' + val + '$' : '', true, false);
            } else {
                column.search('');
            }
            column.draw();

            $.each($('.select-filter', obj.table().header()), function () {
                var select_maj = $('select', this);
                var currentVal = select_maj.val();
                select_maj.find('option').remove().end();
                var columnfiltered = obj.column($(this).index(), {
                    search: 'applied'
                });
                columnfiltered.data().unique().sort().each(function (value, index) {
                    select_maj.append('<option value="' + value + '">' + value + '</option>');
                });
                select_maj.val(currentVal);
            });
        });
    });

    $.each($('.input-filter', obj.table().header()), function () {
        var column = obj.column($(this).index());

        $('input', this).on('keyup change', function () {
            if (column.search() !== this.value) 
            {
                column
                    .search(this.value)
                    .draw();
                $.each($('.select-filter', obj.table().header()),
                    function () {
                        var select_maj = $('select', this);
                        var count = 0;
                        var currentVal = select_maj.val();
                        var tmpVal;
                        select_maj.find('option').remove().end();
                        var columnfiltered = obj.column($(this).index(), {
                            search: 'applied'
                        });
                        columnfiltered.data().unique().sort().each(
                            function (value, index) 
                            {
                                select_maj.append('<option value="' + value + '">' + value + '</option>');
                                tmpVal = value;
                                count++;
                            });
                        select_maj.val(currentVal);
                    });
            }
        });
    });
}

function initDT(dom_id, pagelength, columns, jsonData = null)
{
    $('.buttons-copy, .buttons-csv, .buttons-print, .buttons-pdf, .buttons-excel').addClass('btn mb-2');
    $('.buttons-select-all, .buttons-select-none').addClass('btn mb-2');

    var DT = $(dom_id).DataTable({
        dom: '<"d-flex justify-content-between align-items-center"<"btn-group"B>f>rtip',
        "autoWidth": false,
        colReorder: true,
        "processing": true,
        "columns": columns, 
        keys: true,
        "data": jsonData,
        "ajax": "",
        "scrollX": true,
        rowGroup: {dataSrc: 'title'},
        buttons: ["excel", "csv"],
        "order": [],
        "pageLength": pagelength,
        "orderCellsTop": true,
        "initComplete":function(settings, json){formatInit(settings.oInstance.api())} 
    });

    return DT;
}


function initDTSimple(dom_id, pagelength, columns, jsonData = null)
{
    var DT = $(dom_id).DataTable({
        "autoWidth": false,
        "processing": true,
        keys: true,
        "data": jsonData,
        "ajax": "",
        "scrollX": true,
        "order": [],
        "pageLength": pagelength,
        ordering: false,
        "initComplete":function(settings, json){formatInit(settings.oInstance.api())} 
    });
    return DT;
}
