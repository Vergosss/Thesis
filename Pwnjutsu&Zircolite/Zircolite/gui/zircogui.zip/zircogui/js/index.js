const trashIcon = '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash-2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>'
const crossIcon = '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x-circle"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>'
var filterHTML = '<div class="text-center"><a data-toggle="tooltip" data-placement="top" title="Delete filter" class="clean-filter-btn">' + crossIcon + '</a><a data-toggle="tooltip" data-placement="top" title="Delete all" class="clean-all-filter-btn">' + trashIcon + '</a></div>';
var filterInputFieldHTML = '<th class="input-filter"><input type="text" class="form-control clean-filter" placeholder="Filter"></input></th>';
var filterSelectFieldHTML = '<th class="select-filter"><select class="form-control clean-filter" placeholder="Filter"></select></th>';
var tableVar;
var matrixVar;

function emptyDatatable(){
    $("#dataTable-head").empty();
    $("#dataTable-body").empty();
    $("#dataTable-filter").empty();
    $("#dataTable-filter-foot").empty();
    $("#dataTable-filter-fields").empty();
}

function drawDatatablePrimitive(dataJSON) {
    if(tableVar !== undefined){
        tableVar.clear().destroy();
        emptyDatatable();
    }
    var arrDatatables = buildColumns(getFields(dataJSON));
    tableVar = initDT('#dataTable', 100, arrDatatables, dataJSON);
    $(".clean-filter-btn").on("click",function(){clear(this)});
    $(".clean-all-filter-btn").on("click",function(){trash(this)});
    $("#focus-card").focus();
}

function drawDatatableByClick(obj) {
    $("#loading-spinner").show();
    let key = $(obj).attr("id");

    if( $("#" + key + "-nb").text() !== "0"){
        drawDatatablePrimitive(dictData[key]);
    }
    $("#loading-spinner").hide();
}

function findEventByRowId(dict, row_id) {
    var eventFound = null;
    Object.entries(dict).forEach((phase) => {
        if (eventFound == null){
            phase[1].forEach((event) => {
                if (event["row_id"]==row_id){
                    eventFound = event;
                    return;
                }
            });
        }
    });
    return eventFound;
}

function findEventByRuleTitle(dict, rules) {
    var eventsFound = [];
    const phaseSearch = ["unknown", "low", "medium", "high", "critical"]
    Object.entries(dict).forEach((phase) => {
        if (phaseSearch.includes(phase[0])){
            Object.entries(phase[1]).forEach((event) => {
                if (rules.includes(event[1]["title"])){
                    eventsFound.push(event[1]);
                }
            });
        }
    });
    return eventsFound;
}

function drawDatatableEventList(title) {
    $("#loading-spinner").show();
    drawDatatablePrimitive(findEventByRuleTitle(dictData, title));
    $("#loading-spinner").hide();
}

function drawDatatableEvent(row_id) {
    $("#loading-spinner").show();
    drawDatatablePrimitive([findEventByRowId(dictData, row_id)]);
    $("#loading-spinner").hide();
}

function getFields(dataJSON) {
    let fields;
    dataJSON.forEach(function(item){
        fields = _.union(fields, Object.keys(item));
    });
    return fields;
}

function buildColumns(fields, prefix="dataTable", specialHeaders=true) {
    let counter = 0;
    var arrDatatables = [];
    fields.forEach(function(item){
        arrDatatables.push({"data" : item, "defaultContent" : "", "render":$.fn.dataTable.render.text()});
        $("#" + prefix + "-head").append("<th>" + item + "</th>");
        if(counter <= 1 && specialHeaders){
            $("#" + prefix + "-filter-fields").append(filterSelectFieldHTML);
        }
        else{
            $("#" + prefix + "-filter-fields").append(filterInputFieldHTML);
        }
        $("#" + prefix + "-filter").append("<th>" + filterHTML + "</th>");
        $("#" + prefix + "-foot").append("<th>" + item + "</th>");
        counter++;
    });
    return arrDatatables;
}

var groups = new vis.DataSet([
    { content: "Reconnaissance", id: "reconnaissance", value: 1, className: "reconnaissance" },
    { content: "Resource Development", id: "resource_development", value: 2, className: "resource_development" },
    { content: "Initial Access", id: "initial_access", value: 3, className: "initial_access"},
    { content: "Execution", id: "execution", value: 4, className: "execution"},
    { content: "Persistence", id: "persistence", value: 5, className: "persistence"},
    { content: "Privilege escalation", id: "privilege_escalation", value: 6, className:"privilege_escalation"},
    { content: "Defense Evasion", id: "defense_evasion", value: 7, className: "defense_evasion"},
    { content: "Credential Access", id: "credential_access", value: 8, className: "credential_access"},
    { content: "Discovery", id: "discovery", value: 9, className: "discovery"},
    { content: "Lateral Movement", id: "lateral_movement", value: 10, className: "lateral_movement"},
    { content: "Collection", id: "collection", value: 11, className: "collection"},
    { content: "Command And Control", id: "command_and_control", value: 12, className: "command_and_control"},
    { content: "Exfiltration", id: "exfiltration", value: 13, className: "exfiltration"},
    { content: "Impact", id: "impact", value: 14, className: "impact"},
    { content: "Other", id: "other", value: 15, className: "other"}
  ]);

$(document).ready(function() {

    for (const [key, value] of Object.entries(dictData)){
        $("#" + key + "-nb").text(dictData[key].length);
    }


    if(navigator.userAgent.indexOf("Safari") != -1 && navigator.userAgent.indexOf("Chrome") == -1){
        $("#btn-zoom").hide();
        $("#timeline-text").hide();
        $("#visualization").html("<b>Timeline don't work with Safari</b>");
        $("#matrix-tab").trigger("click");
    }
    else{
        // Init the timeline       
        var container = document.getElementById('visualization');
        var timeline = [];
        var counter = 0;
        var first = new Date("9999-12-12 23:59:59");
        var last = new Date("1970-01-01 00:00:00");

        Object.entries(dictData).forEach((phase) => {
            phaseName = phase[0];
            phase[1].forEach((event) => {
                counter++; 
                dateTest = new Date(event[timeField]);
                if (first > dateTest){first = dateTest;}
                if (last < dateTest){last = dateTest;}
                var eventData;
                Object.entries(event).forEach((data) => {
                    eventData += data + '<br>';
                });
                timeline.push({
                    id: counter, 
                    content:  event["title"] + " - EventID : " + event["EventID"] + ' ' +
                    `<a href="#" class="btn btn-secondary btn-icon-split" onclick='$("#dataTable").trigger("click");drawDatatableEvent("` + event["row_id"] + `");'>
                        <span class="icon text-white-50">
                            <i class="fas fa-arrow-right"></i>
                        </span>
                        <span class="text">Show</span>
                    </a>`,
                    start: event[timeField], title: event[timeField],     
                    group: phaseName, 
                    className: phaseName,
                    custom: event["row_id"]
                });
            });
        });

        var items = new vis.DataSet(timeline);
        // Configuration for the Timeline
        var options = {
            groupOrder: "value",
            dataAttributes: ['id'],
            clickToUse: true,
            xss: {
                disabled: false,
                filterOptions: {
                whiteList: { 
                    a: ['class', 'onclick', 'href'],
                    span: 'class',
                    i: 'class',
                },
                }
            },
            tooltip: {delay: 0},
            start: first,
            end: last
        };


        // Create the Timeline
        var timeline = new vis.Timeline(container,{}, options);
        timeline.setGroups(groups);
        timeline.setItems(items);
        timeline.fit();
        $("#btn-zoom").on('click', function(){timeline.fit()});
    }

    $(".btn-mitre").on('click', function(){drawDatatableByClick(this)});
    $("#loading-spinner").hide();    
    $("#loading-spinner-timeline").hide();

    // Add badge in Matrix
    for (let i = 0; i < mitre.length; i++) { 
        for (let j = 0; j < mitre[i].length; j++) { 
            technique = mitre[i][j].split("-")[0];
            if (tags.includes(technique)){
                mitre[i][j] = mitre[i][j] + " <span class='badge badge-pill badge-danger'>Found</span></a>";
            }
        }
    }

    // Create Matrix
    matrixVar = initDTSimple('#matrix-table', 100, buildColumns(tactics, "matrix-table", false), mitre);
    matrixVar.search("Found").draw();
    $("#btn-reset-search").on('click', function(){matrixVar.search("").draw();});
    $("#btn-search").on('click', function(){matrixVar.search("Found").draw();});

    $('#matrix-table tbody').on( 'click', 'td', function () {
        // Get clicked technique
        var rules = [];
        var technique = matrixVar.cell( this ).data().split("-")[0];
        if (tags.includes(technique)){
            for (const element of attack) {
                if (element[0] == technique) {
                    rules.push(element[1]);
                }
            } 
            drawDatatableEventList(rules);
        }
   });
});
